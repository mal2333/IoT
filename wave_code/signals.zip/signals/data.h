
// ADD YOUR INFO HERE!!

//LINK TO ADAFRUIT IO
#define IO_USERNAME "io_username"
#define IO_KEY "io_key"

//LINK TO WIFI NETWORK
#define WIFI_SSID "wifi_ID"
#define WIFI_PASS "wifi_password"
